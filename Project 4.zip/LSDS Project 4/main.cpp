Certainly! Below is the provided C++ code with added comments for better understanding:

```cpp
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include "Queries_BL.h"
#include <chrono>
#include "searchers.h"
#include "Queries_NW.h"
#define EQUAL 0

using namespace std;

// Main function
int main(int argc, char** argv) {
    // Seed for random number generation
    srand(time(0));

    // Variable declarations
    unsigned int ge_s = 0;  // Genome size
    char* a1 = argv[1];     // Command-line argument 1
    char* a2 = argv[2];     // Command-line argument 2
    char* a3 = argv[3];     // Command-line argument 3
    int t_s = stoi(argv[4]); // Command-line argument 4, converted to integer

    // Extract genome
    char* sub = extract_genome(a1, ge_s);

    // Start the timer
    auto t_start = chrono::high_resolution_clock::now();

    // Part 1A: Perform searches with Needleman-Wunsch algorithm
    if (strcmp(a3, "1A") == EQUAL) {
        Queries_NW a(a2);
        cout << "Total hits: " << perform_searches_nw(sub, ge_s, a, t_s) << endl;
    }

    // Part 1B: Perform random searches with Needleman-Wunsch algorithm
    if (strcmp(a3, "1B") == EQUAL) {
        Queries_NW a(a2);
        cout << "Total hits: " << perform_searches_randomly_nw(a, t_s) << endl;
    }

    // Part 2A: Perform searches with BL algorithm
    if (strcmp(a3, "2A") == EQUAL) {
        Queries_BL a(a2, 16, 11);
        cout << "Total hits: " << perform_searches_bl(sub, ge_s, a, t_s) << endl;
    }

    // Part 2B: Perform random searches with BL algorithm
    if (strcmp(a3, "2B") == EQUAL) {
        Queries_BL a(a2, 16, 11);
        cout << "Total hits: " << perform_searches_randomly_bl(a, t_s) << endl;
    }

    // Stop the timer
    auto clockStop = chrono::high_resolution_clock::now();

    // Calculate time duration
    auto elapsed = chrono::duration_cast<chrono::nanoseconds>(clockStop - t_start);

    // Print the elapsed time in seconds
    cout << "Finished in: " << elapsed.count() / 1000000000 << " seconds" << endl;
    
    // Return 0 to indicate successful program execution
    return 0;
}