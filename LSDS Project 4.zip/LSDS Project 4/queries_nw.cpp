Certainly! Here's the C++ code for the `Queries_NW` class with added comments for better understanding:

```cpp
#include "Queries_NW.h"
using namespace std;

// Constructor for Queries_NW class
Queries_NW::Queries_NW(char* filename) {
    // Initialize member variables
    trans = NULL;
    si_of_fra = 16;
    f_si = 0;

    // Open the file
    ifstream file_handler(filename);

    if (file_handler.is_open()) {
        string str_var;

        // Count the number of lines in the file to determine the value of f_si
        while (file_handler >> str_var) {
            file_handler >> str_var;
            f_si++;
        }

        // Clear the stream and set the position to the beginning of the file
        file_handler.clear();
        file_handler.seekg(0);

        // Allocate memory for the trans array
        trans = new char*[f_si];

        // Read data from the file and allocate space for the trans array
        for (unsigned int vali = 0; vali < f_si; vali++) {
            file_handler >> str_var;
            file_handler >> str_var;

            // Allocate memory for each genomic fragment
            trans[vali] = new char[si_of_fra];
            // Copy the genomic fragment from the file to the trans array
            strncpy(this->trans[vali], str_var.c_str(), 16);
        }
    }
}

// Destructor for Queries_NW class
Queries_NW::~Queries_NW() {
    // Check if trans is not null
    if (trans != nullptr) {
        int i = 0;
        // Loop through the array to deallocate memory for each genomic fragment
        while (i < f_si) {
            if (trans[i]) {
                delete[] trans[i];
                trans[i] = nullptr;
            }
            i++;
        }
        // Deallocate memory for the trans array
        delete[] trans;
        // Set trans to nullptr after deallocating memory
        trans = nullptr;
    }
}

// Function to search for a given n-mer within the Queries_NW class
int Queries_NW::search_for_query(char* s_sq) {
    int b_h_s = -100;
    int cm_f = 0;
    int i = 0;

    // Loop through the genomic fragments to calculate the best score
    while (i < f_si) {
        // Use the needlemanWunsch function to calculate the score
        cm_f = needlemanWunsch(trans[i], s_sq);

        // Check if the current score is greater than the best score
        if (cm_f > b_h_s) {
            // Update the best score
            b_h_s = cm_f;
        }

        // Increment i
        i++;
    }

    // Return the best score
    return b_h_s;
}

// Function to find the maximum value among three integers
int Queries_NW::spmn(int aj, int bj, int cj) {
    // Find the maximum value
    int m = max(aj, bj);
    return max(m, cj);
}

// Function to perform the Needleman-Wunsch algorithm for sequence alignment
int Queries_NW::needlemanWunsch(char* s1, char* s2) {
    // Get the lengths of the input sequences
    int l1 = strlen(s1);
    int l2 = strlen(s2);

    // Initialize vectors for previous and current row in the dynamic programming matrix
    vector<int> prev(l2 + 1);
    vector<int> cur(l2 + 1);

    int j = 0;
    // Initialize the first row of the matrix
    while (j <= l2) {
        prev[j] = j * (-1);
        j++;
    }

    int i = 1;
    // Loop through the input sequences to fill the dynamic programming matrix
    while (i <= l1) {
        cur[0] = i * (-1);
        int j = 1;
        while (j <= l2) {
            // Use a genomic similarity scoring matrix (+2 for match, -1 for mismatch) and a gap penalty (-1)
            int d = prev[j - 1] + s_eval(s1[i - 1], s2[j - 1]);
            int u = prev[j] - 1;
            int le = cur[j - 1] - 1;
            // Calculate the maximum value among the three options
            cur[j] = spmn(d, u, le);
            j++;
        }
        // Swap the vectors for the next iteration
        prev.swap(cur);
        i++;
    }

    // Return the final score
    return prev[l2];
}

// Function to evaluate similarity between characters
int Queries_NW::s_eval(char f_i, char s_i) {
    // Check if characters are equal and are one of A, C, G, T, or N
    if (f_i == s_i && (f_i == 'A' || f_i == 'C' || f_i == 'G' || f_i == 'T' || f_i == 'N')) {
        return 2;
    }

    // Return the mismatch penalty
    return -1;
}
