#include "Queries_NW.h"
#include "Queries_BL.h"
#include <iostream>
#include <ctime>
#include <fstream>
#include <cstring>
#include <algorithm>
#include <climits>

using namespace std;

// Function to perform searches randomly with Blast
int perform_searches_randomly_bl(Queries_BL& obj, int t_s) {
    int r_N = 0;
    char ran[16];
    int sc = 0;
    char* b_m = NULL;
    int cc = 0;

    // Loop for generating random sequences and performing searches
    for (int i = 0; i < t_s; i++) {
        for (int j = 0; j < 16; j++) {
            // Generate a random number to choose a character (A, C, G, T, N)
            r_N = rand() % 5;
            
            // Map the random number to a character
            switch (r_N) {
                case 0:
                    ran[j] = 'A';
                    break;
                case 1:
                    ran[j] = 'C';
                    break;
                case 2:
                    ran[j] = 'G';
                    break;
                case 3:
                    ran[j] = 'T';
                    break;
                case 4:
                    ran[j] = 'N';
                    break;
            }
        }

        // Perform a search for the generated sequence
        char* temp = obj.search_for_query(ran, sc);

        // If the score is greater than or equal to twice the length of the sequence, count it as a hit
        if (sc >= 2 * 13)
            cc++;
    }

    // Return the count of hits
    return cc;
}

// Function to accumulate hit count
int accumulate_cc(int cc, int sc, int thr) {
    // If the score is greater than or equal to the threshold, increment the hit count
    return cc + (sc >= thr);
}

// Function to perform searches with Newman-Wunsch
int perform_searches_nw(char*& sub, unsigned int sub_size, Queries_NW& obj, int t_s) {
    int r_N = 0;
    char ran[16];
    int sc = 0;
    char* b_m = NULL;
    int cc = 0;
    int thr = 2 * 13;  // Threshold for counting hits

    // Loop for generating random sequences and performing searches
    int i = 0;
    while (i < t_s) {
        // Generate a random starting index within the sub sequence
        r_N = rand() % (sub_size - 15);

        // Copy a 16-character subsequence from the specified starting index
        int j = 0;
        while (j < 16) {
            ran[j] = sub[r_N + j];
            j++;
        }

        // Perform a search for the generated subsequence
        sc = obj.search_for_query(ran);

        // Accumulate hits based on the score and threshold
        cc = accumulate_cc(cc, sc, thr);

        // Increment loop counter
        i++;
    }

    // Return the count of hits
    return cc;
}

// Function to perform searches randomly with Newman-Wunsch
int perform_searches_randomly_nw(Queries_NW& obj, int t_s) {
    int r_N = 0;
    char ran[16];
    int sc = 0;
    char* b_m = NULL;
    int cc = 0;

    // Loop for generating random sequences and performing searches
    for (int i = 0; i < t_s; i++) {
        for (int j = 0; j < 16; j++) {
            // Generate a random number to choose a character (A, C, G, T, N)
            r_N = rand() % 5;

            // Map the random number to a character
            switch (r_N) {
                case 0:
                    ran[j] = 'A';
                    break;
                case 1:
                    ran[j] = 'C';
                    break;
                case 2:
                    ran[j] = 'G';
                    break;
                case 3:
                    ran[j] = 'T';
                    break;
                case 4:
                    ran[j] = 'N';
                    break;
            }
        }

        // Perform a search for the generated sequence
        sc = obj.search_for_query(ran);

        // If the score is greater than or equal to twice the length of the sequence, count it as a hit
        if (sc >= 2 * 13)
            cc++;
    }

    // Return the count of hits
    return cc;
}

// Function to extract genomic sequence from a file
char* extract_genome(const char* filename, unsigned int& genome_size) {
    ifstream file_handler(filename);

    // Check if the file is open
    if (!file_handler.is_open()) {
        cout << "File " << filename << " could not be opened!";
        return NULL;
    }

    genome_size = 0;
    string readLine;

    // Calculate the total length of the genomic sequence
    while (getline(file_handler, readLine)) {
        if (readLine.empty() || readLine[0] == '>') {
            continue;
        }
        genome_size += readLine.length();
    }

    // Clear the file stream and set the position to the beginning of the file
    file_handler.clear();
    file_handler.seekg(0);

    // Allocate memory for the genomic sequence
    char* sub = new char[genome_size + 1];
    sub[genome_size] = '\0';

    unsigned int k = 0;

    // Extract the genomic sequence from the file
    for (unsigned int i = 0; i < genome_size; i += readLine.length()) {
        getline(file_handler, readLine);
        if (readLine.empty() || readLine[0] == '>') {
            i -= readLine.length();
            continue;
        }
        for (unsigned int j = 0; j < readLine.length(); j++) {
            sub[k++] = readLine[j];
        }
    }

    // Return the genomic sequence
    return sub;
}

// Function to perform searches with Blast
int perform_searches_bl(char*& sub, unsigned int sub_size, Queries_BL& obj, int t_s) {
    int r_N = 0;
    char ran[16];
    int sc = 0;
    char* b_m = NULL;
    int cc = 0;
    int thr = 2 * 13;  // Threshold for counting hits

    // Loop for generating random sequences and performing searches
    int i = 0;
    while (i < t_s) {
        // Generate a random starting index within the sub sequence
        r_N = rand() % (sub_size - 15);

        // Copy a 16-character subsequence from the specified starting index
        int j = 0;
        while (j < 16) {
            ran[j] = sub[r_N + j];
            j++;
        }

        // Perform a search for