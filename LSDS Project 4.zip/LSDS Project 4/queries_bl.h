Certainly! Below is the C++ code for the `Queries_BL` class with added comments for better understanding:

```cpp
#pragma once
#include "Queries_BL.h"

#include <fstream>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <iterator>
#include <climits>

// Class definition for Queries_BL
class Queries_BL {
    int s_f;      // Fragment capacity
    int ss_size;  // Word size
    char **tran;  // 2D array to store sequences
    int f_size;   // Size of the array

public:
    // Constructor for Queries_BL class
    Queries_BL(char* filename, int fragment_capacity, int word_size);

    // Destructor for Queries_BL class
    ~Queries_BL();

    // Method to load data from a file
    void load_data(std::ifstream& file_handler, int fragment_capacity, int word_size);

    // Needleman-Wunsch algorithm for sequence alignment
    int needlemanWunsch(char* compare1, char* compare2);

    // Method to search for a query sequence
    char* search_for_query(char* single_seq, int &max_found_score);

    // Method to evaluate similarity between characters
    int s_eval(char a, char b);

    // Method to find the maximum value among three integers
    int smn(int a, int b, int c);

    // Method to find occurrences of a substring in a larger string
    int* fi_se(std::string query, std::string fragment, int &seedCount);

    // Method to deallocate memory for the sequences
    void del_frag();

    // Needleman-Wunsch algorithm for sequence alignment with memoization
    int n_m(int i, int j, char* seq1, char* seq2, int memo[][17]);
};

// Constructor for Queries_BL class
Queries_BL::Queries_BL(char* filename, int fragment_capacity, int word_size) {
    // Initialize variables
    f_size = 0;
    s_f = fragment_capacity;
    ss_size = word_size;

    // Open file
    std::ifstream file_handler;
    file_handler.open(filename, std::ios::in);

    // Check if the file is open
    if (!file_handler.is_open()) {
        std::cout << "File not found or Permission denied" << std::endl;
    } else {
        // Load data from the file
        load_data(file_handler, fragment_capacity, word_size);
    }
}

// Destructor for Queries_BL class
Queries_BL::~Queries_BL() {
    // Deallocate memory for sequences
    del_frag();
    std::cout << "Destroyed class object" << std::endl;
}

// Method to load data from a file
void Queries_BL::load_data(std::ifstream& file_handler, int fragment_capacity, int word_size) {
    std::string seq_value;

    // Count the number of sequences in the file
    while (file_handler >> seq_value) {
        if (seq_value[0] != '>') {
            f_size++;
        }
    }

    // Close and reopen the file to read sequences
    file_handler.close();
    file_handler.open(filename, std::ios::in);

    // Allocate memory for storing sequences
    tran = new char*[f_size];

    unsigned int vali = 0;
    // Read sequences from the file
    while (file_handler >> seq_value) {
        if (seq_value[0] != '>') {
            tran[vali] = new char[fragment_capacity + 1];
            std::strncpy(tran[vali], seq_value.c_str(), fragment_capacity);
            tran[vali][fragment_capacity] = '\0';
            vali++;
        }
    }

    // Print the content of the 'tran' array
    std::cout << "Content of 'tran' array:" << std::endl;
    for (int i = 0; i < f_size; i++) {
        std::cout << tran[i] << std::endl;
    }
}

// Needleman-Wunsch algorithm for sequence alignment
int Queries_BL::needlemanWunsch(char* compare1, char* compare2) {
    const int l = 16;
    int memo[17][17];

    // Initialize the memoization table with INT_MAX
    for (int i = 0; i <= l; ++i) {
        for (int j = 0; j <= l; ++j) {
            memo[i][j] = INT_MAX;
        }
    }

    int i = 0;
    int j = 0;

    // Base cases: Fill the first row and column of the memo array
    while (i <= l) {
        memo[i][0] = i * (-1);
        i++;
    }
    while (j <= l) {
        memo[0][j] = j * (-1);
        j++;
    }

    i = 1;
    while (i <= l) {
        j = 1;
        while (j <= l) {
            if (compare1[i - 1] == compare2[j - 1]) {
                memo[i][j] = memo[i - 1][j - 1] + 2;
            } else {
                int di = memo[i - 1][j - 1] - 1;
                int upper = memo[i - 1][j] - 1;
                int le = memo[i][j - 1] - 1;

                memo[i][j] = std::max({ di, upper, le });
            }
            j++;
        }
        i++;
    }

    return memo[l][l];
}

// Method to search for a query sequence
char* Queries_BL::search_for_query(char* single_seq, int &max_found_score) {
    int b_h_s = -99999;
    char* b_m = NULL;
    int c_f_s;
    int i = 0;
    while (i < f_size) {
        int s_t;
        int* s_p = fi_se(single_seq, tran[i], s_t);
        int k = 0;
        while (k < s_t) {
            int loca = s_p[k];
            c_f_s = needlemanWunsch(single_seq, tran[i] + loca);
            if (c_f_s > b_h_s) {
                b_h_s = c_f_s;
                b_m = tran[i];
            }
            k++;
        }
        delete[] s_p;
        i++;
    }

    max_found_score = b_h_s;
    return b_m;
}

// Method to evaluate similarity between characters
int Queries_BL::s_eval(char a, char b) {
    return (a == b) ? 2 : -1;
}

// Method to find the maximum value among three integers
int Queries_BL::smn(int a, int b, int c) {
    int max = a;
    if (b > max) {
        max = b;
    } else if (c > max) {
        max = c;
    }
    return max;
}

// Method to find occurrences of a substring in a larger string
int* Queries_BL::fi_se(std::string query, std::string fragment, int &seedCount) {
    seedCount = 0;
    int len_qu = query.length();
    int len_frag = fragment.length();
