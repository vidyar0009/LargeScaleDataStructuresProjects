Certainly! Here's the C++ code for the `Queries_NW` class with added comments:

```cpp
#pragma once

#include <iostream>
#include <ctime>
#include <fstream>
#include <cstring>
#include <algorithm>
#include <climits>
#include <vector>

using namespace std;

// Class definition for Queries_NW
class Queries_NW {
    int si_of_fra;  // Size of the genomic fragments
    char **trans;   // 2D array to store genomic fragments
    unsigned int f_si;  // Number of genomic fragments

public:
    // Constructor for Queries_NW class
    Queries_NW(char* file_name);

    // Destructor for Queries_NW class
    ~Queries_NW();

    // Needleman-Wunsch algorithm for sequence alignment
    int needlemanWunsch(char* compare1, char* compare2);

    // Needleman-Wunsch algorithm for sequence alignment with memoization
    int nw_memo(int i, int j, char* compare1, char* compare2, int memo[][17]);

    // Function to search for a query sequence
    int search_for_query(char* single_seq);

    // Function to find the maximum value among three integers
    int spmn(int a, int b, int c);

    // Function to evaluate similarity between characters
    int s_eval(char a, char b);
};

// Constructor for Queries_NW class
Queries_NW::Queries_NW(char* file_name) {
    // Initialize member variables
    trans = nullptr;
    si_of_fra = 16;
    f_si = 0;

    // Open the file
    ifstream file_handler(file_name);

    if (file_handler.is_open()) {
        string str_var;

        // Count the number of lines in the file to determine the value of f_si
        while (file_handler >> str_var) {
            file_handler >> str_var;
            f_si++;
        }

        // Clear the stream and set the position to the beginning of the file
        file_handler.clear();
        file_handler.seekg(0);

        // Allocate memory for the trans array
        trans = new char*[f_si];

        // Read data from the file and allocate space for the trans array
        for (unsigned int vali = 0; vali < f_si; vali++) {
            file_handler >> str_var;
            file_handler >> str_var;

            // Allocate memory for each genomic fragment
            trans[vali] = new char[si_of_fra];
            // Copy the genomic fragment from the file to the trans array
            strncpy(this->trans[vali], str_var.c_str(), 16);
        }
    }
}

// Destructor for Queries_NW class
Queries_NW::~Queries_NW() {
    // Check if trans is not null
    if (trans != nullptr) {
        int i = 0;
        // Loop through the array to deallocate memory for each genomic fragment
        while (i < f_si) {
            if (trans[i]) {
                delete[] trans[i];
                trans[i] = nullptr;
            }
            i++;
        }
        // Deallocate memory for the trans array
        delete[] trans;
        // Set trans to nullptr after deallocating memory
        trans = nullptr;
    }
}

// Needleman-Wunsch algorithm for sequence alignment
int Queries_NW::needlemanWunsch(char* compare1, char* compare2) {
    // Get the lengths of the input sequences
    int l1 = strlen(compare1);
    int l2 = strlen(compare2);

    // Initialize vectors for previous and current row in the dynamic programming matrix
    vector<int> prev(l2 + 1);
    vector<int> cur(l2 + 1);

    int j = 0;
    // Initialize the first row of the matrix
    while (j <= l2) {
        prev[j] = j * (-1);
        j++;
    }

    int i = 1;
    // Loop through the input sequences to fill the dynamic programming matrix
    while (i <= l1) {
        cur[0] = i * (-1);
        int j = 1;
        while (j <= l2) {
            // Use a genomic similarity scoring matrix (+2 for match, -1 for mismatch) and a gap penalty (-1)
            int d = prev[j - 1] + s_eval(compare1[i - 1], compare2[j - 1]);
            int u = prev[j] - 1;
            int le = cur[j - 1] - 1;
            // Calculate the maximum value among the three options
            cur[j] = spmn(d, u, le);
            j++;
        }
        // Swap the vectors for the next iteration
        prev.swap(cur);
        i++;
    }

    // Return the final score
    return prev[l2];
}

// Needleman-Wunsch algorithm for sequence alignment with memoization
int Queries_NW::nw_memo(int i, int j, char* compare1, char* compare2, int memo[][17]) {
    // Assuming a maximum size of 17 for memo array

    // Initialize the memo array with INT_MAX
    for (int m = 0; m <= i; m++) {
        for (int n = 0; n <= j; n++) {
            memo[m][n] = INT_MAX;
        }
    }

    // Base cases
    for (int m = 0; m <= i; m++) {
        memo[m][0] = m * (-1);
    }
    for (int n = 0; n <= j; n++) {
        memo[0][n] = n * (-1);
    }

    // Filling in the memo array using dynamic programming
    for (int m = 1; m <= i; m++) {
        for (int n = 1; n <= j; n++) {
            if (compare1[m - 1] == compare2[n - 1]) {
                memo[m][n] = memo[m - 1][n - 1] + 2;
            } else {
                int di = memo[m - 1][n - 1] - 1;
                int upper = memo[m - 1][n] - 1;
                int le = memo[m][n - 1] - 1;

                memo[m][n] = spmn(di, upper, le);
            }
        }
    }

    // Return the final score
    return memo[i][j];
}

// Function to search for a query sequence
int Queries_NW::search_for_query(char* single_seq) {
    int b_h_s = -100;
    int cm_f = 0;
    int i = 0;

    // Loop through the genomic fragments to calculate the best score
    while (i < f_si) {
        // Use the needlemanWunsch function to calculate the score
        cm_f = needlemanWunsch(trans[i], single_seq);

        // Check if the current score is greater than the best score
        if (cm_f > b_h_s) {
            // Update the best score
            b_h_s = cm_f;
        }

        // Increment i
        i++;
    }

    // Return the best score
    return