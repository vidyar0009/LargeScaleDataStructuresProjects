#!/bin/bash
#SBATCH --job-name=myJob        
#SBATCH --output=/scratch/sr3229/output.txt    
#SBATCH --error=/scratch/sr3229/error.txt                   
#SBATCH --nodes=1
#SBATCH --mem=5000
#SBATCH --ntasks-per-node=1         
#SBATCH --cpus-per-task=1         
#SBATCH --time=3:00

g++ /scratch/sr3229/genome.cpp -o /scratch/sr3229/genome

srun /scratch/sr3229/genome /common/contrib/classroom/inf503/genomes/human.txt