#include <iostream>
#include <fstream>
#include <chrono>
#include <climits>

using namespace std;
using namespace std::chrono;

// Global variables with new names and clearer purposes
int maxScaffoldLength = INT_MIN;
int minScaffoldLength = INT_MAX;
int scaffoldCount = 0;
long int countA = 0;
long int countC = 0;
long int countG = 0;
long int countT = 0;
long int countN = 0;
int countMisc = 0;
string longestScaffoldName;
string shortestScaffoldName;

// Function to count characters
int countCharacter(char geneChar)
{
    int increment = 0;
    switch (geneChar)
    {
    case 'A':
        countA++;
        increment = 1;
        break;
    case 'C':
        countC++;
        increment = 1;
        break;
    case 'G':
        countG++;
        increment = 1;
        break;
    case 'T':
        countT++;
        increment = 1;
        break;
    case 'N':
        countN++;
        increment = 1;
        break;
    default:
        if (geneChar == '>')
        {
            scaffoldCount++;
        }
        break;
    }
    return increment;
}

// Function to read the file
string readGenomeFile(const string &filename)
{
    ifstream inputFile(filename);
    if (!inputFile)
    {
        cerr << "Failed to open file: " << filename << endl;
        exit(EXIT_FAILURE);
    }

    int currentScaffoldLength = 0;
    string currentScaffoldName = "";
    string genomeData = "";
    char currentCharacter;

    while (inputFile.get(currentCharacter))
    {
        currentScaffoldLength += countCharacter(currentCharacter);

        if (!isalpha(currentCharacter) && currentCharacter != '>')
        {
            currentScaffoldName += currentCharacter;
        }
        else if (currentCharacter == '>' && scaffoldCount > 1)
        {
            if (currentScaffoldLength >= maxScaffoldLength)
            {
                maxScaffoldLength = currentScaffoldLength;
                longestScaffoldName = currentScaffoldName;
            }
            if (currentScaffoldLength < minScaffoldLength)
            {
                minScaffoldLength = currentScaffoldLength;
                shortestScaffoldName = currentScaffoldName;
            }
            currentScaffoldName = "";
            currentScaffoldLength = 0;
        }

        if (isalpha(currentCharacter))
        {
            genomeData += currentCharacter;
        }
    }

    inputFile.close();
    return genomeData;
}

// Function to print genome data
void printGenomeData()
{
    long int totalCharacterCount = countA + countC + countG + countT + countN + countMisc;
    cout << "A count: " << countA << endl;
    cout << "C count: " << countC << endl;
    cout << "G count: " << countG << endl;
    cout << "T count: " << countT << endl;
    cout << "Other characters: " << countMisc << endl;
    cout << "Total gene character count: " << totalCharacterCount << endl;
    cout << "C & G percentage: " << (float)((countC + countG) * 100) / (float)totalCharacterCount << "%" << endl;
    cout << "Total number of scaffolds: " << scaffoldCount << endl;
    cout << "Average length of scaffold: " << totalCharacterCount / scaffoldCount << endl;
    cout << "Largest scaffold length: " << maxScaffoldLength << endl;
    cout << "Largest scaffold name: " << longestScaffoldName << endl;
    cout << "Smallest scaffold length: " << minScaffoldLength << endl;
    cout << "Smallest scaffold name: " << shortestScaffoldName << endl;
}

int main(int argc, char **argv)
{
    // Start time measurement
    auto startTime = high_resolution_clock::now();

    string genomeData = readGenomeFile(argv[1]);

    // End time measurement
    auto endTime = high_resolution_clock::now();

    // Output genome data
    printGenomeData();

    // Calculate execution time
    duration<double> executionTime = endTime - startTime;
    cout << "Time for execution: " << executionTime.count() << " seconds" << endl;

    return 0;
}

