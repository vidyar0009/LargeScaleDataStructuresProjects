#include <fstream>
#include <iomanip>
#include <chrono>
#include <cmath>
#include <cstring>
#include <iostream>

struct Node{
	
	char* base;
	Node *link;
	
};

class Queries_HT{
	
	int len; 
	Node **chain;
	
public:

	Queries_HT(int len); 
	~Queries_HT();
	//bool search(const char* base); 
	bool search(const char* base, unsigned int length);
	bool insertQuery(const char* base); 
	double computeHash(const char* base); 
	long long int fillHT(char* file_to_read); 
};
