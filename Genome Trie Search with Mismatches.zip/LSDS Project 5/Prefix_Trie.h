struct trie_node_instance{
	trie_node_instance* N_trie;
	int depth;		
	trie_node_instance* T_trie;
	char character;
	trie_node_instance* G_trie;
	trie_node_instance* A_trie;
	trie_node_instance* C_trie;
};


class PrefixTrie{

	trie_node_instance *trie_origin;
	unsigned int nodes_count;

public:

	int search_prefix_trie(const char* insert_query);
	PrefixTrie(char* variants, unsigned int node_counter, bool error);
	PrefixTrie();
	~PrefixTrie();
	PrefixTrie(const PrefixTrie& copy_constructor);
	void adding_trie(char* insert_query);
	trie_node_instance *copy_prefix_trie_node(const trie_node_instance *node_instanceect);
	
	void deleteTrie(trie_node_instance *node_instanceect);
	bool f_sea(char* insert_query);
	unsigned int get_nodes_count();
	
};


