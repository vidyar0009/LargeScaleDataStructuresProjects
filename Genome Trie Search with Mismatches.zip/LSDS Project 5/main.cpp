#include <iostream>
#include <random>
#include <ctime>
#include <fstream>
#include "Prefix_Trie.h"  // Include the header file for PrefixTrie implementation

using namespace std;

const int p_s = 50000;

// Function to extract a segment of length p_s from a given genomic sequence
void get_seg(char*& h_g, unsigned int g_s, char*& ran_dna) {

    unsigned int st_p = rand() % (g_s - p_s + 1);
    unsigned int i = 0;

    while (i < p_s) {
        ran_dna[i] = h_g[st_p + i];
        i++;
    }
}

// Function to generate genomic read from a FASTA file
char* gen_read(char* f_id, unsigned int& g_s) {
    fstream fileheader;
    fileheader.open(f_id, ios::in);
    unsigned int ki = 0;

    if (!fileheader.is_open()) {
        cout << "File " << f_id << " not found";  // Print an error message if file not found
        return NULL;
    }

    string readLine;
    while (fileheader >> readLine) {
        if (readLine[0] != '>') {
            g_s += readLine.length();
        }
    }

    fileheader.clear();
    fileheader.seekg(0);
    char* h_g = new char[g_s + 1];
    h_g[g_s] = '\0';
    int i = 0;

    while (fileheader >> readLine) {
        if (readLine[0] != '>') {
            int lineLength = readLine.length();
            int j = 0;
            while (j < lineLength) {
                h_g[i + j] = readLine[j];
                j++;
            }
            ki += lineLength;
        }
    }

    fileheader.close();
    return h_g;
}

int main(int argc, char** argv) {
    srand(time(0));

    if (argc < 4) {
        cout << "Insufficient arguments" << endl;
        return -1;
    }

    char* f_id = argv[1];
    char s_p = argv[2][0];
    int n = stoi(argv[3]);

    cout << endl;

    unsigned int g_s = 0;
    char* h_g = gen_read(f_id, g_s);

    if (s_p == 'A') {
        char* ran_dna;
        ran_dna = new char[p_s + 1];
        ran_dna[p_s] = '\0';

        get_seg(h_g, g_s, ran_dna);

        PrefixTrie prefixTr(ran_dna, n, false);  // Instantiate PrefixTrie with random DNA and specified length

        cout << "Amount of substring matches -- " << prefixTr.search_prefix_trie(ran_dna) << endl;
        cout << "Data Struct Size -- " << prefixTr.get_nodes_count() << endl;
    } else {
        cout << "Wrong subproblem name: " << s_p << endl;
    }

    return 0;
}
