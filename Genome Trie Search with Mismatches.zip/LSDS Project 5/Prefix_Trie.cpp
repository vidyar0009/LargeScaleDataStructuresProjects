#include "Prefix_Trie.h"
#include <cstddef>
#include <iostream>
#include <stack>
#include <cstring>

using namespace std;

const int pat_s = 50000;

// Structure to hold search data for prefix trie
struct SearchData {
    trie_node_instance* node;
    int le;
    int tole;

    // Constructor for SearchData
    SearchData(trie_node_instance* n, int l, int t) : node(n), le(l), tole(t) {}
};

// Function to search for a pattern in the prefix trie
bool PrefixTrie::searchPattern(char* ins_q) {
    stack<SearchData> stack;
    stack.push(SearchData(trie_origin, 0, 0));

    while (!stack.empty()) {
        SearchData next = stack.top();
        stack.pop();
        trie_node_instance* node = next.node;
        int le = next.le;
        int tole = next.tole;

        if (le == 36 && tole <= 1) {
            return true;  // Pattern found
        }

        char ba[] = {'A', 'C', 'G', 'T'};
        trie_node_instance* chi[] = {node->A_trie, node->C_trie, node->G_trie, node->T_trie};

        for (int i = 0; i < 4; ++i) {
            char current_base = ba[i];

            if (chi[i] != nullptr && (ins_q[le] == current_base || tole < 1)) {
                int next_tole = (ins_q[le] == current_base) ? tole : tole + 1;
                stack.push(SearchData(chi[i], le + 1, next_tole));
            }
        }
    }

    return false;  // Pattern not found
}

// Function to add a pattern to the prefix trie
void PrefixTrie::addPattern(char* ins_q) {
    trie_node_instance* newChild = this->trie_origin;

    for (int i = 0; i < 36; i++) {
        trie_node_instance** next_trie;

        if (ins_q[i] == 'G')
            next_trie = &newChild->G_trie;
        else if (ins_q[i] == 'A')
            next_trie = &newChild->A_trie;
        else if (ins_q[i] == 'N')
            next_trie = &newChild->N_trie;
        else if (ins_q[i] == 'C')
            next_trie = &newChild->C_trie;
        else if (ins_q[i] == 'T')
            next_trie = &newChild->T_trie;
        else
            return;

        if (*next_trie != NULL) {
            newChild = *next_trie;
        } else {
            *next_trie = new trie_node_instance;
            newChild = *next_trie;

            newChild->A_trie = NULL;
            newChild->C_trie = NULL;
            newChild->G_trie = NULL;
            newChild->N_trie = NULL;
            newChild->T_trie = NULL;
            newChild->depth = i + 1;

            this->nodes_count++;
        }
    }
}

// Constructor to generate a prefix trie with random patterns
PrefixTrie::PrefixTrie(char* variants, unsigned int n, bool error) : PrefixTrie() {
    int rv;
    char ins_q[37] = {0};
    int i = 0;

    while (i < n) {
        rv = rand() % (pat_s - 35);
        int j = 0;

        while (j < 36) {
            ins_q[j] = variants[rv + j];

            if (error && static_cast<float>(rand()) / static_cast<float>(RAND_MAX) < 0.05) {
                char choose_from[] = {'A', 'C', 'G', 'T', 'N'};
                ins_q[j] = choose_from[rand() % 5];
            }
            j++;
        }

        this->addPattern(ins_q);
        i++;
    }
}

// Function to search for patterns in a given sequence
int PrefixTrie::searchPatternsInSequence(const char* ins_q) {
    int hits = 0;
    char fragment[36];

    int i = 0;
    while (i < pat_s - 35) {
        int j = 0;
        while (j < 36) {
            fragment[j] = ins_q[j + i];
            j++;
        }

        hits += searchPattern(fragment);

        i++;
    }

    return hits;
}

// Default constructor to initialize a prefix trie
PrefixTrie::PrefixTrie() {
    this->nodes_count = 0;
    this->trie_origin = new trie_node_instance;
    this->trie_origin->C_trie = NULL;
    this->trie_origin->T_trie = NULL;
    this->trie_origin->G_trie = NULL;
    this->trie_origin->A_trie = NULL;
    this->trie_origin->N_trie = NULL;
    this->trie_origin->character = 'S';  // Set root character
}

//
