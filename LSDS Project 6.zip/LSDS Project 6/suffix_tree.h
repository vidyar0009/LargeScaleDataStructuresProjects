#ifndef SUFFIX_TREE_H
#define SUFFIX_TREE_H

#include <cstring>
#include <fstream>
#include <ctime>
#include <iostream>

#define dataset_size 50000

class suffix_tree {
public:
    static const int count_alpha = 5;

    // Structure representing a node in the suffix tree
    struct dtype {
        int begg;           // Start index of the substring represented by the node
        int *last;          // End index of the substring represented by the node
        bool sherd;         // Flag indicating whether the 'last' pointer is shared
        dtype *next_ptr;    // Pointer to the next node in the linked list of nodes
        dtype *sub_crds[count_alpha];  // Array of pointers to child nodes corresponding to different characters

        dtype(int begg, int *last, bool sherd = false);
        ~dtype();
    };

    // Constructor
    suffix_tree(const char *gen_hnm);
    // Destructor
    ~suffix_tree();
    // Function to delete nodes in the suffix tree
    void purge_tree(dtype *root);

    // Function to search for a sequence in the suffix tree
    bool per_hits_searchVAR(const char *seq_single, int &node_at) const;
    // Function to get the count of nodes in the suffix tree
    int get_node_count() const;

private:
    dtype *rootNode;    // Pointer to the root node of the suffix tree
    const char *gen_hnm;    // Pointer to the input genomic sequence
    int cntr;           // Counter for the number of nodes in the suffix tree
    int t_chars;        // Total number of characters in the input genomic sequence

    // Function to convert a character to its corresponding index
    int c_to_i(char c) const;
    // Function to convert an index to its corresponding character
    char indexToChar(int array_index) const;
    // Function to build the suffix tree
    void tree_making();
};

#endif
