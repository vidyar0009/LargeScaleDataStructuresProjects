#include "suffix_tree.h"
using namespace std;

#include <map>

// Function to convert a character to its corresponding index
int suffix_tree::c_to_i(char ch) const {
    static std::map<char, int> charMap = {{'A', 0}, {'C', 1}, {'G', 2}, {'T', 3}, {'N', 4}};
    auto it = charMap.find(ch);
    if (it == charMap.end()) {
        exit(-1);
    } else {
        return it->second;
    }
}

// Function to convert an index to its corresponding character
char suffix_tree::indexToChar(int array_index) const {
    char table_lu[] = {'A', 'C', 'G', 'T', 'N'};

    if (array_index < 0 && array_index > 5) {
        return '\0';
    } else {
        return table_lu[array_index];
    }
}

// Destructor for the suffix_tree class
suffix_tree::~suffix_tree() {
    if (!rootNode) {
        purge_tree(rootNode);
    }
}

// Recursive function to delete nodes in the suffix tree
void suffix_tree::purge_tree(dtype* root) {
    if (root) {
        int i = 0;
        while (i < count_alpha) {
            purge_tree(root->sub_crds[i]);
            i++;
        }
        delete root;
    } else {
        return;
    }
}

// Function to search for a sequence in the suffix tree
bool suffix_tree::per_hits_searchVAR(const char* seq_single, int& node_at) const {
    dtype* nodeptr_child = rootNode;
    int len_sing_seq = std::strlen(seq_single);
    int i = 0;
    bool fnd = false;
    for (i = 0; i < len_sing_seq; ++i) {
        char c = seq_single[i];
        int array_index = c_to_i(c);
        dtype* child = nodeptr_child->sub_crds[array_index];
        if (!child) {
            return false;
        }
        nodeptr_child = child;
        int begg = nodeptr_child->begg;
        int last = *nodeptr_child->last;
        fnd = false;
        int j = begg;
        while (j <= last && !fnd) {
            if (gen_hnm[j] == c) {
                fnd = true;
            }
            ++j;
        }
        if (!fnd) {
            return false;
        }
    }

    node_at = nodeptr_child->begg - (len_sing_seq - (*nodeptr_child->last - nodeptr_child->begg + 1));
    return true;
}

// Function to get the count of nodes in the suffix tree
int suffix_tree::get_node_count() const {
    return cntr;
}

// Constructor for the inner dtype class
suffix_tree::dtype::dtype(int begg, int* last, bool sherd)
    : begg(begg), last(last), sherd(sherd), next_ptr(NULL) {

    int i = 0;
    while (i < count_alpha) {
        sub_crds[i] = NULL;
        i++;
    }
}

// Destructor for the inner dtype class
suffix_tree::dtype::~dtype() {
    for (int i = 0; i < count_alpha; ++i) {
        if (sub_crds[i] != NULL) {
            delete sub_crds[i];
        }
    }
    if (sherd == false && last != NULL) {
        delete last;
    }
}

// Constructor for the suffix_tree class
suffix_tree::suffix_tree(const char* gen_hnm) : gen_hnm(gen_hnm), cntr(0), t_chars(std::strlen(gen_hnm)) {
    tree_making();
}

// Function to build the suffix tree
void suffix_tree::tree_making() {
    int last = -1;
    rootNode = new dtype(-1, &last);
    cntr++;

    dtype* last_node = NULL;
    dtype* act_type = rootNode;
    int edge_curr = -1;
    int act_len = 0;
    int rem_tot = 0;

    // Lambda function to split a node
    auto split = [&](dtype* root) -> dtype* {
        int indx_new = c_to_i(gen_hnm[root->begg + act_len]);
        dtype* dummy = new dtype(root->begg, new int(root->begg + act_len - 1), true);
        cntr++;
        act_type->sub_crds[c_to_i(gen_hnm[edge_curr])] = dummy;
        dummy->sub_crds[indx_new] = root;
        root->begg += act_len;
        return dummy;
    };

    // Lambda function to walk along the tree
    auto walk = [&](dtype* root) -> bool {
        if (act_len >= *root->last - root->begg + 1) {
            edge_curr += *root->last - root->begg + 1;
            act_len -= *root->last - root->begg + 1;
            act_type = root;
            return true;
        }
        return false;
    };

    int i = 0;
    while (i < t_chars) {
        last = i;
        rem_tot++;
        last_node = NULL;

        while (rem_tot > 0) {
            if (act_len == 0) {
                edge_curr = i;
            }

            int array_index = c_to_i(gen_hnm[edge_curr]);
            if (!act_type->sub_crds[array_index]) {
                act_type->sub_crds[array_index] = new dtype(i, &last);
                cntr++;

                if (last_node != NULL) {
                    last_node->next_ptr = act_type;
                    last_node = NULL;
                }
            } else {
                dtype* next = act_type->sub_crds[array_index];
                if (walk(next)) {
                    continue;
                }

                if (gen_hnm[next->begg + act_len] == gen_hnm[i]) {
                    if (last_node != NULL && act_type != rootNode) {
                        last_node->next_ptr = act_type;
                        last_node = NULL;
                    }
                    act_len++;
                    break;
                }

                dtype* spt_d_type = split(next);
                int indx_new = c_to_i(gen_hnm[i]);
                spt_d_type->sub_crds[indx_new] = new dtype(i, &last);
                cntr++;

                if (last_node != NULL) {
                    last_node->next_ptr = spt_d_type;
                }
                last_node = spt_d_type;
            }

            rem_tot--;
            if (act_type == rootNode && act_len > 0) {
                act_len--;
                edge_curr = i - rem_tot + 1;
            } else {
                act_type = act_type->next_ptr != NULL ? act_type->next_ptr : rootNode;
            }
        }

        i++;
    }
}
