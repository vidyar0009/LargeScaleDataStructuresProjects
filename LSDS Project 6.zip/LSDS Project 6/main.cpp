#include "suffix_tree.h"
using namespace std;

// Function to read the human genome data from a file
// and store it in the hg_txt character array
unsigned int hum_gen_read(ifstream& file_handle, char*& hg_txt) {
    unsigned int g_len = 0;
    string l_V;

    // Read data from the file, excluding lines starting with '>'
    while (file_handle >> l_V) {
        if (l_V[0] != '>') {
            g_len += l_V.length();
        }
    }

    // Allocate memory for hg_txt based on the length of the genome
    hg_txt = new char[g_len];

    // Reset file stream and read the data again
    file_handle.clear();
    file_handle.seekg(0);

    unsigned int k = 0;
    while (file_handle >> l_V) {
        if (l_V[0] != '>') {
            // Copy the DNA sequence into hg_txt
            unsigned int i = 0;
            while (i < l_V.length()) {
                hg_txt[i + k] = l_V[i];
                i++;
            }
            k += l_V.length();
        }
    }

    return g_len;
}

// Function to search the suffix tree for random DNA sequences
int q_tree(suffix_tree& isnt, char* rand_DNA, int gen_frag_len, int sch_cnt) {
    int hits_fnd = 0;

    // Generate random 36-mer and search suffix tree for matches
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, gen_frag_len - 36);

    int i = 0;
    while (i < sch_cnt) {
        int num_rnd = dis(gen);
        std::string seq_single(&rand_DNA[num_rnd], 36);
        int lctd = 0;
        // Search for the sequence in the suffix tree
        if (isnt.per_hits_searchVAR(seq_single.c_str(), lctd)) {
            hits_fnd += 1;
        } else {
            hits_fnd += 0;
        }
        i++;
    }

    return hits_fnd;
}

int main(int argc, char** argv) {
    srand(time(0));

    // Check if the correct number of arguments are provided
    if (argc < 3) {
        cout << "Check the arguments" << endl;
        exit(-1);
    }

    // Read the human genome data from the specified file
    unsigned int t_chars = 0;
    ifstream data(argv[1]);
    char* sjt;
    t_chars = hum_gen_read(data, sjt);

    // Generate a random DNA sequence of length 50000
    int gen_frag_len = 50001;
    char* rand_DNA = new char[50000 + 1];
    rand_DNA[50000] = 0;

    // Select a random starting position in the genome
    unsigned int begg = rand() % (t_chars - 50000 + 1);

    // Copy the selected DNA sequence into rand_DNA
    unsigned int i = 0;
    while (i < 50000) {
        rand_DNA[i] = sjt[begg + i];
        i++;
    }

    // Create a suffix tree object with the random DNA sequence
    suffix_tree suffix_tree_object(rand_DNA);
    cout << "Count of elements in Tree: " << suffix_tree_object.get_node_count() << endl;

    // Search the suffix tree for random DNA sequences and print the occurrences
    int fnd = q_tree(suffix_tree_object, rand_DNA, 50000, stoi(argv[2]));
    cout << "Occurrences: " << fnd << endl;

    return 0;
}
