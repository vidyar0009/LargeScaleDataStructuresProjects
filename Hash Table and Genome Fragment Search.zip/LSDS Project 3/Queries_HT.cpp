#include "Queries_HT.h"
using namespace std;

double Queries_HT::computeHash(const char* base) {
    unsigned long long computed_hash = 14695981039346656037ULL;

    for (int i = 0; i < 16; i++) {
        computed_hash = (computed_hash ^ base[i]) * 1099511628211ULL;
    }

    return fmod(computed_hash, len);
}

long long int Queries_HT::fillHT(char* file_to_read) {
    ifstream filePointer(file_to_read);

    if (!filePointer.is_open()) {
        cout << "Error in file handling" << endl;
        exit(-1);
    }

    string tmp;
    double collisionsCount = 0;

    while (filePointer >> tmp) {
        if (tmp[0] != '>') {
            if (insertQuery(tmp.c_str())) {
                collisionsCount++;
            }
        }
    }

    return collisionsCount;
}

bool Queries_HT::insertQuery(const char* base) {
    double computed_hash = computeHash(base);

    if (chain[(unsigned int)computed_hash] == NULL) {
        chain[(unsigned int)computed_hash] = new Node;
        chain[(unsigned int)computed_hash]->link = NULL;
        chain[(unsigned int)computed_hash]->base = new char[17];
        strncpy(chain[(unsigned int)computed_hash]->base, base, 16);
        chain[(unsigned int)computed_hash]->base[16] = '\0';
        return false;
    } else {
        Node* newNode = new Node;
        newNode->base = new char[17];
        strncpy(newNode->base, base, 16);
        newNode->base[16] = '\0';
        newNode->link = chain[(unsigned int)computed_hash];
        chain[(unsigned int)computed_hash] = newNode;
        return true;
    }
}

Queries_HT::~Queries_HT() {
    for (int i = 0; i < len; i++) {
        Node* temp = chain[i];

        while (temp) {
            Node* tNode2 = temp;
            temp = temp->link;
            delete[] tNode2->base;
            delete tNode2;
        }
    }

    delete[] chain;
}

Queries_HT::Queries_HT(int len) {
    this->len = len;
    this->chain = new Node*[len];

    for (int i = 0; i < len; i++)
        this->chain[i] = NULL;
}

bool Queries_HT::search(const char* base, unsigned int length){
//bool Queries_HT::search(const char* base) {
    Node* head = chain[(unsigned int)computeHash(base)];

    if (head == NULL)
        return false;

    Node* temp = head;

    while (temp) {
        bool matched = true;
        for (int i = 0; i < 16; i++) {
            if (temp->base[i] != base[i]) {
                matched = false;
                break;
            }
        }

        if (matched) {
            return true;
        }

        temp = temp->link;
    }

    return false;
}
