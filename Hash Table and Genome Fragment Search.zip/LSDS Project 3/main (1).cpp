#include <iostream>
#include "Queries_HT.h"
#include <fstream>
#include <chrono>

using namespace std;

void load_genome_file(string filename, char*& sub, unsigned int& genome_size) {
    ifstream filePointer(filename);

    if (!filePointer) {
        cerr << "Error: Unable to open genome file." << endl;
        exit(-1);
    }

    string tmp;
    unsigned int len = 0;

    while (filePointer >> tmp) {
        if (tmp[0] != '>') {
            len += tmp.length();
        }
    }

    genome_size = len;
    sub = new char[len];

    filePointer.clear();  // Clear the EOF flag.
    filePointer.seekg(0);  // Reset the file pointer.

    len = 0;

    while (filePointer >> tmp) {
        if (tmp[0] != '>') {
            for (int i = 0; i < tmp.length(); i++) {
                sub[i + len] = tmp[i];
            }
            len += tmp.length();
        }
    }
}

int main(int argc, char** argv) {
   

    char operation = argv[3][0];
    int len = (argc >= 5 && operation == 'A') ? atoi(argv[4]) : 60000000;
    unsigned int totalMatched = 0;

    Queries_HT hashTable(len);

    if (operation == 'A') {
        auto start = chrono::high_resolution_clock::now();
        hashTable.fillHT(argv[1]);
        auto stop = chrono::high_resolution_clock::now();
        cout << "Insertion time in seconds: " << chrono::duration_cast<chrono::seconds>(stop - start).count() << endl;
        return 0;
    } else if (operation == 'B') {
        cout << "Filling hashtable with queries.." << endl;
        hashTable.fillHT(argv[1]);

        unsigned int genome_size;
        char* sub;
        load_genome_file(argv[2], sub, genome_size);

        auto start = chrono::high_resolution_clock::now();
        totalMatched = hashTable.search(sub, genome_size);  // Use hashTable to call the search function
        auto stop = chrono::high_resolution_clock::now();
        cout << "Searching time in seconds: " << chrono::duration_cast<chrono::seconds>(stop - start).count() << endl;

        // Clean up allocated memory
        delete[] sub;

        return 0;
    }
}
