#include "main.h"
int main (int argc, char **argv)
{
    Queries_AR tumma(argv[1],argv[2],argv[3]);
    return 0;
}



