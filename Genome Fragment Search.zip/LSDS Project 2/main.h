#ifndef spider
#define spider
#endif
#include <cstring>
#include <ctime>
#include <iostream>
#include <fstream>
#include <chrono>
using namespace std;

class Queries_AR{
    private:
        char** file2 = new char*[35000000];
    public:
     Queries_AR (){
       for (long int q = 0;q<35000000;q++){
           file2[q] = new char[32];
       }
       for (long int q = 0;q<35000000;q++){
           for (int r = 0; r<32; r++)
           file2[q][r] = 0;
       }
   }
   
   int my_strcmp(char* q_temp, char* q_array);
   Queries_AR(string,string,char*); 
   long int binary_search(long int, long int , char* );
    void parta(char*,long int,long int);
    long int l_search(long int , long int ,char* );
    void query_sort(long int );
    void mergeSort( long int ,char** , long int );
    void partb(char*,long int,long int);
    
    ~Queries_AR (){
       for (long int q = 0;q<35000000;q++){
           delete[] file2[q]; 
       }
       delete[] file2;
   }
};