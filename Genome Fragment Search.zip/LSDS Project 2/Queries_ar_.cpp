#include "main.h"
#include <iostream>
#include <fstream>
#include <string>
#include <chrono>

class Queries_AR {
private:
    char file2[35000000][32]; // Assuming file2 is an array of strings (32 characters each)

    // Function to perform linear search within file2
    long int l_search(long int i_index, long int q_index, char* file1) {
        char q_temp[33];
        long int q = 0;

        for (int q1 = 0; q1 < 32; q1++) {
            q_temp[q1] = file1[i_index + q1];
        }

        while (q <= q_index) {
            if (my_strcmp(q_temp, file2[q]) == 0) {
                return q + 1;
            }
            q++;
        }

        return -1;
    }

    // Function to perform binary search within file2
    long int binary_search(long int a_index, long int q_index, char* file1) {
        char q_temp[33];
        for (int q1 = 0; q1 < 32; q1++) {
            q_temp[q1] = file1[a_index + q1];
        }

        long int low = 0;
        long int high = q_index - 1;

        while (low <= high) {
            long int mid = (low + high) / 2;
            int cmp = my_strcmp(file2[mid], q_temp);
            if (cmp == 0) {
                return mid + 1;
            } else if (cmp < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return -1;
    }

    // Custom string comparison function
    int my_strcmp(char* str1, char* str2) {
        for (int i = 0; i < 32; i++) {
            if (str1[i] < str2[i])
                return -1;
            else if (str1[i] > str2[i])
                return 1;
        }
        return 0;
    }

    // MergeSort implementation for sorting file2
    void mergeSort(long int right, char** arr, long int left) {
        if (left < right) {
            long int mid = left + (right - left) / 2;
            mergeSort(mid, arr, left);
            mergeSort(right, arr, mid + 1);

            long int a, b, c;
            long int i = mid - left + 1;
            long int j = right - mid;
            char** Le = new char*[i];
            char** Ri = new char*[j];

            for (a = 0; a < i; a++)
                Le[a] = arr[left + a];
            for (b = 0; b < j; b++)
                Ri[b] = arr[mid + 1 + b];

            a = 0;
            b = 0;
            c = left;

            while (a < i && b < j) {
                if (my_strcmp(Le[a], Ri[b]) <= 0) {
                    arr[c] = Le[a];
                    a++;
                } else {
                    arr[c] = Ri[b];
                    b++;
                }
                c++;
            }

            while (a < i) {
                arr[c] = Le[a];
                a++;
                c++;
            }

            while (b < j) {
                arr[c] = Ri[b];
                b++;
                c++;
            }

            delete[] Ri;
            delete[] Le;
        }
    }

public:
    Queries_AR(string file1_path, string path_query, char* part) {
        long int q_index = 0;
        char* file1 = new char[3060000000];
        string fline;
        long int i_index = 0;
        ifstream file1_;
        file1_.open(file1_path);
        ifstream qfile;
        qfile.open(path_query);

        cout << "Begin Reading Files" << endl;
        do {
            getline(file1_, fline);
            if (fline[0] == '>') {
                // Handle header lines if needed
            } else {
                for (int i = 0; i < fline.size(); i++) {
                    file1[i_index++] = fline[i];
                }
            }
        } while (file1_);

        for (long int q = 0; q < 35000000; q++) {
            for (int r = 0; r < 32; r++) {
                file2[q][r] = 0;
            }
        }

        while (qfile) {
            getline(qfile, fline);
            if (fline[0] == '>') {
                // Handle header lines if needed
            } else {
                for (int i = 0; i < fline.size(); i++) {
                    file2[q_index][i] = fline[i];
                }
                q_index++;
            }
        }
        cout << "Done Reading Files" << endl;

        if (*part == 'A') {
            parta(file1, q_index, i_index);
        } else if (*part == 'B') {
            partb(file1, q_index, i_index);
        }
    }

    // Implement part A logic
    void parta(char* file1, long int q_index, long int i_index) {
        // Your previous parta function
    }

    // Implement part B logic
    void partb(char* file1, long int q_index, long int i_index) {
        // Your previous partb function
    }

    // Sort file2 using mergeSort
    void query_sort(long int q_index) {
        cout << "Sorting starting" << endl;
        mergeSort(q_index - 1, file2, 0);
        cout << "Done sorting" << endl;
    }
};

int main() {
    // You can create an instance of the Queries_AR class and call its constructor to run the code.
    // For example:
    // Queries_AR queries("file1_path.txt", "path_query.txt", "A");
    return 0;
}
